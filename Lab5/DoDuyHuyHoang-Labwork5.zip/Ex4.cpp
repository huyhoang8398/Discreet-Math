#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// input number of production then input production, symbol go from A->Z
// input must have left-hand side symbol, coefficient and right-hand side symbol.
// if there is no coefficient or right-handside symbol, use dot (.) to fill.
// with @ is a start symbol
// lamda = ^
// nothing = .
// ex: 6
// production:				input this:
// @ -> Lamda				@.^ 
// @ -> 0					@0.
// @ -> 0B					@0B
// @ -> 1A					@1C
// A -> 1					A1.
// B -> 1					B1.

int n;
int product[100][3];

void input(FILE * stream) {
	//each symbol is considered as a state
	fscanf(stream,"%d",&n);
	fscanf(stream,"\n");
	for (int i = 0; i < n; ++i)
	{
		int k = 0;
		while (k < 3) {
			char c;
			fscanf(stream, "%c",&c );
			product[i][k] = c;
			k++;
			//printf("%c ",c );
		}	
		//printf("\n");
		fscanf(stream,"\n");
	}

	int max = product[0][0] - 64;
	for (int i = 0; i < n; ++i)
	{
		product[i][0] -= 64;
		if (product[i][0] > max)
		{
			max = product[i][0];
		}
		product[i][1] -=48;
	}
	//add 1 state as final state
	product[n][0] = max+1;
	n++;

}

void show() {
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			printf("%d ", product[i][j]);
		}
		printf("\n");
	}
}

int main(int argc, char const *argv[])
{
	FILE * pfile = fopen("input4.txt","r");
	input(pfile);
	fclose(pfile);


	show();
	return 0;
}