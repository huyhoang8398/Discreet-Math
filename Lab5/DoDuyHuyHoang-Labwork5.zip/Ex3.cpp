#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//input n states, m alphabets, [n]x[m] function, <fnum> number of final states
//and a string with the length of <Len>.

int n, m;
int func[100][100][100];
int fnum;
int final[100];
int len;
int s[1000];

// --How to input a NFA
// line1: number of state <n> - number of alphabet <m>
// ex: 5 2
// --
// line2 -> m+1 <3> : (in state 0) each line represent an alphabet which contain number of possible state and then list all states
// state 0: alphabet 0 : 2 possible states : 0 & 2
// 		 alphabet 1 : 1 possible states : 1
// state 1: alphabet 0 : 1 possible states : 3
// 		 alphabet 1 : 1 possible states : 4
// ex: 2 0 2
// 	1 1
// 	1 3
// 	1 4
// ... -> line nxm+1 <11>


void input(FILE * stream) {
	fscanf(stream,"%d",&n);
	fscanf(stream,"%d",&m);
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			fscanf(stream,"%d", &func[i][j][0]);
			for (int k = 1; k <= func[i][j][0]; ++k)
			{
				fscanf(stream,"%d", &func[i][j][k]);
			}	
		}	
	}
	fscanf(stream,"%d",&fnum);
	for (int i = 0; i < fnum; ++i)
	{
		fscanf(stream,"%d",&final[i]);
	}

}

void generate_grammar() {
	printf("G = (V , T , S, P );\n");
	printf("V = [\n");
	for (int i = 0; i < n; ++i)
	{
		printf("s%d ~ %c,\n", i,(char) i+64);
	}
	for (int i = 0; i < m; ++i)
	{
		printf("%d,", i);
	}
	printf("];\n");
	printf("T = [");
	for (int i = 0; i < m; ++i)
	{
		printf("%d ", i);
	}
	printf("];\n");
	printf("@ is the start symbol.\n");

	printf("Production:\n" );
	//if s0 is a final then include @ -> lamda
	for (int i = 0; i < fnum; ++i)
	{
		if (final[i] == 0)
		{
			printf("@ -> Lamda\n");
		}
	}
}

bool checkfinal(int state) {
	for (int i = 0; i < fnum; ++i)
	{
		if (state == final[i])
		{
			return true;
		}
	}
	return false;
}

void generate_production() {
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			for (int k = 1; k <= func[i][j][0]; ++k)
			{
				if (checkfinal(func[i][j][k]) == false)
				{
					printf("%c -> %d%c\n",(char) i+64,j,(char) func[i][j][k]+64 );	
				}
				else
					printf("%c -> %d\n",(char) i+64,j);
			}
		}
	}
}

int main(int argc, char const *argv[])
{
	FILE * pfile = fopen("input3.txt","r");
	input(pfile);
	fclose(pfile);

	generate_grammar();
	generate_production();
	return 0;
}