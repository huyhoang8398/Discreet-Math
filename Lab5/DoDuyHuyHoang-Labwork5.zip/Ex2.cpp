#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//input n states, m alphabets, [n]x[m] function, <fnum> number of final states
//and a string with the length of <Len>.

int n, m;
int func[100][100][100];
int fnum;
int final[100];
int len;
int s[1000];

// --How to input a NFA
// line1: number of state <n> - number of alphabet <m>
// ex: 5 2
// --
// line2 -> m+1 <3> : (in state 0) each line represent an alphabet which contain number of possible state and then list all states
// state 0: alphabet 0 : 2 possible states : 0 & 2
// 		 alphabet 1 : 1 possible states : 1
// state 1: alphabet 0 : 1 possible states : 3
// 		 alphabet 1 : 1 possible states : 4
// ex: 2 0 2
// 	1 1
// 	1 3
// 	1 4
// ... -> line nxm+1 <11>
// --the following lines :
// 1: the number of final states
// 2: list all final states
// 3: length of the string
// 4: list the string


void input(FILE * stream) {
	fscanf(stream,"%d",&n);
	fscanf(stream,"%d",&m);
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			fscanf(stream,"%d", &func[i][j][0]);
			for (int k = 1; k <= func[i][j][0]; ++k)
			{
				fscanf(stream,"%d", &func[i][j][k]);
			}	
		}	
	}
	fscanf(stream,"%d",&fnum);
	for (int i = 0; i < fnum; ++i)
	{
		fscanf(stream,"%d",&final[i]);
	}
	fscanf(stream,"%d",&len);
	fscanf(stream,"\n" );
	for (int i = 0; i < len; ++i)
	{
		char c;
		fscanf(stream,"%c",&c);
		s[i] = (int)c;
		s[i] -=48;
	}
}

void recognize(int x, int status) {
	//if went through all string, check the last state if it is a final state
	if (x == len)
	{
		for (int i = 0; i < fnum; ++i)
		{
			if (status == final[i])
			{
				printf("recognized\n");
				exit(0);
			}
		}
		return ;
	}
	//check every possible states
	for (int i = 1; i <= func[status][s[x]][0]; ++i)
	{
		recognize(x+1,func[status][s[x]][i]);
	}
}

int main(int argc, char const *argv[])
{
	FILE * pfile = fopen("input2.txt","r");
	input(pfile);
	fclose(pfile);

	
	recognize(0,0);
	printf("not recognized\n");
	return 0;
}