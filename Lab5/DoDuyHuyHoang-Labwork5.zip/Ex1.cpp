#include <stdio.h>
#include <string.h>

//input n states, m alphabets, [n]x[m] function, <fnum> number of final states
//and a string with the length of <Len>.

int n, m;
int func[100][100];
int fnum;
int final[100];
int len;
int s[1000];

void input(FILE * stream) {
	fscanf(stream,"%d",&n);
	fscanf(stream,"%d",&m);
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			fscanf(stream,"%d", &func[i][j]);	
		}	
	}
	fscanf(stream,"%d",&fnum);
	for (int i = 0; i < fnum; ++i)
	{
		fscanf(stream,"%d",&final[i]);
	}
	fscanf(stream,"%d",&len);
	fscanf(stream,"\n" );
	for (int i = 0; i < len; ++i)
	{
		char c;
		fscanf(stream,"%c",&c);
		s[i] = (int)c;
		s[i] -=48;
	}
}

bool recognize() {
	//init start state is s0
	int i = 0;
	int status = 0;

	//get the data in the string to determine the next state
	while (i < len) {
		status = func[status][s[i]];
		i++;
	}	

	//check if the last state is a final state
	for (int i = 0; i < fnum; ++i)
	{
		if (status == final[i])
		{
			return true;
		}
	}
	return false;
}

int main(int argc, char const *argv[])
{
	FILE * pfile = fopen("input1.txt","r");
	input(pfile);
	fclose(pfile);

	bool result = recognize();
	if (result)
	{
		printf("recognized\n");
	}
	else {
		printf("not recognized\n");
	}
	return 0;
}